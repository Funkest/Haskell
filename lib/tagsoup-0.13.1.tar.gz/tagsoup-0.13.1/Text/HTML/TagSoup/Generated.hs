module Text.HTML.TagSoup.Generated(parseTagsOptions) where
import Text.HTML.TagSoup.Manual
